import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import pickle as pk
import warnings

# Classification

from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import ComplementNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.naive_bayes import CategoricalNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

def knn(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    
    n_neighbors_list = [1, 3, 5, 7, 9, 11]
    algorithms = ['auto', 'ball_tree', 'kd_tree', 'brute']
    weights_list = ['uniform', 'distance']
    
    df = pd.DataFrame(index=range(1, 47), columns=['n_neighbors', 'algorithm', 'weights', 'accuracy Value'])
    
    accuracy = []
    
    row_idx = 1
    for n_neighbors in n_neighbors_list:
        for algorithm in algorithms:
            for weights in weights_list:
                classifier = KNeighborsClassifier(n_neighbors=n_neighbors, algorithm=algorithm, weights=weights)
                classifier.fit(X_train, y_train.values.ravel())
                
                Y_pred = classifier.predict(X_test).round()
                acc = accuracy_score(y_test, Y_pred)
                accuracy.append(acc)
                
                df.loc[row_idx] = [n_neighbors, algorithm, weights, acc]
                row_idx += 1
    
    max_acc = max(accuracy)
    min_acc = min(accuracy)
    best_param_idx = accuracy.index(max_acc)
    best_param = df.loc[best_param_idx + 1, ['n_neighbors', 'algorithm', 'weights']].to_dict()
    
    print(f"Best parameters for KNN Classifier: {best_param} with an accuracy of {max_acc}")
    
    return df, max_acc, min_acc, best_param
def decision_tree(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    criteria = ['log_loss', 'gini', 'entropy']
    max_features = [None, 'sqrt', 'log2']
    splitters = ['best', 'random']
    df = pd.DataFrame(index=range(1, 19), columns=['Criterion', 'Max Features', 'Splitter', 'accuracy Value'])
    row_idx = 1
    accuracy = []
    for criterion in criteria:
        for max_feature in max_features:
            for splitter in splitters:
                classifier = DecisionTreeClassifier(criterion=criterion, max_features=max_feature, splitter=splitter, random_state=0)
                classifier.fit(X_train, y_train.values.ravel())
                Y_pred = classifier.predict(X_test).round()
                acc = accuracy_score(y_test, Y_pred)
                accuracy.append(acc)
                df.loc[row_idx] = [criterion, max_feature, splitter, acc]
                row_idx += 1
    max_acc = max(accuracy)
    min_acc = min(accuracy)
    best_param_idx = accuracy.index(max_acc)
    best_param = df.loc[best_param_idx + 1, ['Criterion', 'Max Features', 'Splitter']].to_dict()
    print(f"Best parameters for Decision Tree Classifier: {best_param} with an accuracy of {max_acc}")
    return df, max_acc, min_acc, best_param

def random_forest(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    criteria = ['gini', 'entropy', 'log_loss']
    max_features = [None, 'sqrt', 'log2']
    n_estimators = [10, 100]
    df = pd.DataFrame(index=range(1, 19), columns=['Criterion', 'Max Features', 'n_estimators', 'Accuracy'])
    row_idx = 1
    accuracy = []
    for criterion in criteria:
        for max_feature in max_features:
            for n_estimator in n_estimators:
                classifier = RandomForestClassifier(criterion=criterion, max_features=max_feature, n_estimators=n_estimator, random_state=0)
                classifier.fit(X_train, y_train.values.ravel())
                y_pred = classifier.predict(X_test)
                acc = accuracy_score(y_test, y_pred)
                accuracy.append(acc)
                df.loc[row_idx] = [criterion, max_feature, n_estimator, acc]
                row_idx += 1
    max_acc = max(accuracy)
    min_acc = min(accuracy)
    best_param_idx = accuracy.index(max_acc)
    best_param = df.loc[best_param_idx + 1, ['Criterion', 'Max Features', 'n_estimators']].to_dict()
    print(f"Best parameters for Random Forest Classifier: {best_param} with an accuracy of {max_acc}")
    return df, max_acc, min_acc, best_param
def fit(x, y):
    warnings.filterwarnings('ignore')
    models = [
        ('Random Forest', RandomForestClassifier()),
        ('Gaussian Naive Bayes', GaussianNB()),
        ('Multinomial Naive Bayes', MultinomialNB()),
        ('Complement Naive Bayes', ComplementNB()),
        ('Bernoulli Naive Bayes', BernoulliNB()),
        ('Categorical Naive Bayes', CategoricalNB()),
        ('Decision Tree', DecisionTreeClassifier()),
        ('Support Vector Machine', SVC()),
        ('KNN', KNeighborsClassifier())
    ]
    
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    
    model_accuracy_table = pd.DataFrame(index=[1, 2, 3], columns=['Metrics', 'Random Forest', 'Gaussian Naive Bayes', 'Multinomial Naive Bayes', 'Complement Naive Bayes', 'Bernoulli Naive Bayes', 'Categorical Naive Bayes', 'Decision Tree', 'Support Vector Machine', 'KNN'])
    
    Metrics = ['accuracy', 'Micro Average', 'Macro Average']
    
    model_accuracy_table['Metrics'] = Metrics
    
    for name, model in models:
        model.fit(X_train,y_train.values.ravel()  )
        y_pred = model.predict(X_test)
        report = classification_report(y_test, y_pred, output_dict=True)
        accuracy = accuracy_score(y_test, y_pred)
        
        f1_0 = report['0']['f1-score']
        f1_1 = report['1']['f1-score']
        
        support_0 = report['0']['support']
        support_1 = report['1']['support']
        
        MicroAvg = (f1_0 * support_0 + f1_1 * support_1) / (support_0 + support_1)
        MacroAvg = (f1_0 + f1_1) / 2
        
        model_accuracy_table.loc[1, name] = accuracy
        model_accuracy_table.loc[2, name] = MicroAvg
        model_accuracy_table.loc[3, name] = MacroAvg
        
    acc_max = np.max(model_accuracy_table.iloc[:, 1:].values)
    best_model_name = model_accuracy_table.columns[model_accuracy_table.isin([acc_max]).any()].tolist()[0]
    
    print(f'As a result {best_model_name}, served as a best model with an accuracy of {acc_max}')
        
    return model_accuracy_table

def fit_save(x, y):
    warnings.filterwarnings('ignore')
    models = [
        ('Random Forest', RandomForestClassifier()),
        ('Gaussian Naive Bayes', GaussianNB()),
        ('Multinomial Naive Bayes', MultinomialNB()),
        ('Complement Naive Bayes', ComplementNB()),
        ('Bernoulli Naive Bayes', BernoulliNB()),
        ('Categorical Naive Bayes', CategoricalNB()),
        ('Decision Tree', DecisionTreeClassifier()),
        ('Support Vector Machine', SVC()),
        ('KNN', KNeighborsClassifier())
    ]
    
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    
    model_accuracy_table = pd.DataFrame(index=[1, 2, 3], columns=['Metrics', 'Random Forest', 'Gaussian Naive Bayes', 'Multinomial Naive Bayes', 'Complement Naive Bayes', 'Bernoulli Naive Bayes', 'Categorical Naive Bayes', 'Decision Tree', 'Support Vector Machine', 'KNN'])
    
    Metrics = ['accuracy', 'Micro Average', 'Macro Average']
    
    model_accuracy_table['Metrics'] = Metrics
    
    for name, model in models:
        model.fit(X_train,y_train.values.ravel()  )
        y_pred = model.predict(X_test)
        report = classification_report(y_test, y_pred, output_dict=True)
        accuracy = accuracy_score(y_test, y_pred)
        
        f1_0 = report['0']['f1-score']
        f1_1 = report['1']['f1-score']
        
        support_0 = report['0']['support']
        support_1 = report['1']['support']
        
        MicroAvg = (f1_0 * support_0 + f1_1 * support_1) / (support_0 + support_1)
        MacroAvg = (f1_0 + f1_1) / 2
        
        model_accuracy_table.loc[1, name] = accuracy
        model_accuracy_table.loc[2, name] = MicroAvg
        model_accuracy_table.loc[3, name] = MacroAvg
        
    acc_max = np.max(model_accuracy_table.iloc[:, 1:].values)
    best_model_name = model_accuracy_table.columns[model_accuracy_table.isin([acc_max]).any()].tolist()[0]
    print(f'As a result {best_model_name}, served as a best model with an accuracy of {acc_max}')
    
    print('')
    
    print('Saving the best model ...........')
    
    print('')
            
    best_model = [model for name, model in models if name == best_model_name][0]
    
    fileName = f"Finalized_model_{best_model_name}_Classif.sav"
    
    pk.dump(best_model, open(fileName, 'wb'))
    
    print('Model Saved succesfully') 
    
    print('')
            
    print(f"{fileName} is ready for deployment")      
        
    return model_accuracy_table