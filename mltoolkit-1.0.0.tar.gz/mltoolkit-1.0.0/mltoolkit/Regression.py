import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import pickle as pk
import warnings

# Regression

from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import PoissonRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error,r2_score,mean_squared_error
from sklearn.metrics import r2_score


def svm(x, y):

    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)

    C = [10, 100, 500, 1000, 2000, 3000, 7000]
    kernels = ['linear', 'rbf', 'poly', 'sigmoid']

    df = pd.DataFrame(index=range(1, 8), columns=['C'] + kernels)
    df['C'] = ['C 10', 'C 100', 'C 500', 'C 1000', 'C 2000', 'C 3000', 'C 7000']
    accuracy = []
    for i, c in enumerate(C, start=1):
        for kernel in kernels:
            regressor = SVR(kernel=kernel, C=c)
            regressor.fit(X_train, y_train.values.ravel())
            Y_pred = regressor.predict(X_test)
            r_score = r2_score(y_test, Y_pred)
            accuracy.append((r_score, c, kernel))
            df.loc[i, kernel] = r_score
    max_acc = max(accuracy, key=lambda x: x[0])
    min_acc = min(accuracy, key=lambda x: x[0])
    best_param = f"Kernel: {max_acc[2]}, C: {max_acc[1]}"
    acclin = df['linear'].values.astype(float)
    accrbf = df['rbf'].values.astype(float)
    accpoly = df['poly'].values.astype(float)
    accsig = df['sigmoid'].values.astype(float)
    plt.plot(C, acclin, color='b')
    plt.plot(C, accrbf, color='r')
    plt.plot(C, accpoly, color='g')
    plt.plot(C, accsig, color='k')
    plt.title('Accuracy')
    plt.ylabel('Accuracy')
    plt.xlabel('Regularization Parameter (C)')
    plt.legend(["linear", "rbf", "poly", "sigmoid"], loc="lower right")
    plt.show()
    print(f"Best parameters for Support Vector Regressor: {best_param} with an accuracy of {max_acc}")
    return df, max_acc[0], min_acc[0], best_param
def knn(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    
    n_neighbors_list = [1, 3, 5, 7, 9, 11]
    algorithms = ['auto', 'ball_tree', 'kd_tree', 'brute']
    weights_list = ['uniform', 'distance']
    
    df = pd.DataFrame(columns=['n_neighbors', 'algorithm', 'weights', 'R² Value'])
    
    accuracy = []
    
    row_idx = 0
    for n_neighbors in n_neighbors_list:
        for algorithm in algorithms:
            for weights in weights_list:
                regressor = KNeighborsRegressor(n_neighbors=n_neighbors, algorithm=algorithm, weights=weights)
                regressor.fit(X_train, y_train)
                
                Y_pred = regressor.predict(X_test)
                r_score = r2_score(y_test, Y_pred)
                
                df.loc[row_idx] = [n_neighbors, algorithm, weights, r_score]
                accuracy.append(r_score)
                row_idx += 1
    
    max_acc = max(accuracy)
    min_acc = min(accuracy)
    best_param_idx = accuracy.index(max_acc)
    best_param = df.loc[best_param_idx, ['n_neighbors', 'algorithm', 'weights']].to_dict()
    
    print(f"Best parameters for KNN Regressor: {best_param} with an accuracy of {max_acc}")
    
    return df, max_acc, min_acc, best_param
def decision_tree(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    criteria = ['squared_error', 'absolute_error', 'friedman_mse', 'poisson']
    max_features = [None, 'sqrt', 'log2']
    splitters = ['best', 'random']
    df = pd.DataFrame(index=range(1, 19), columns=['Criterion', 'Max Features', 'Splitter', 'R² Value'])
    row_idx = 1
    accuracy = []
    for criterion in criteria:
        for max_feature in max_features:
            for splitter in splitters:
                regressor = DecisionTreeRegressor(criterion=criterion, max_features=max_feature, splitter=splitter, random_state=0)
                regressor.fit(X_train, y_train)
                Y_pred = regressor.predict(X_test)
                r_score = r2_score(y_test, Y_pred)
                accuracy.append(r_score)
                df.loc[row_idx] = [criterion, max_feature, splitter, r_score]
                row_idx += 1
    max_acc = max(accuracy)
    min_acc = min(accuracy)
    best_param_idx = accuracy.index(max_acc)
    best_param = df.loc[best_param_idx + 1, ['Criterion', 'Max Features', 'Splitter']].to_dict()
    
    print(f"Best parameters for Decision Tree Regressor: {best_param} with an accuracy of {max_acc}")
    return df, max_acc, min_acc, best_param

def random_forest(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    criteria = ['squared_error', 'absolute_error', 'friedman_mse', 'poisson']
    max_features = [None, 'sqrt', 'log2']
    n_estimators = [10, 100]
    df = pd.DataFrame(index=range(1, 13), columns=['Criterion', 'Max Features', 'n_estimators', 'R² Value'])
    row_idx = 1
    accuracy = []
    for criterion in criteria:
        for max_feature in max_features:
            for n_estimator in n_estimators:
                regressor = RandomForestRegressor(criterion=criterion, max_features=max_feature, n_estimators=n_estimator, random_state=0)
                regressor.fit(X_train, y_train.values.ravel())
                Y_pred = regressor.predict(X_test)
                r_score = r2_score(y_test, Y_pred)
                accuracy.append(r_score)
                df.loc[row_idx] = [criterion, max_feature, n_estimator, r_score]
                row_idx += 1
    max_acc = max(accuracy)
    min_acc = min(accuracy)
    best_param_idx = accuracy.index(max_acc)
    best_param = df.loc[best_param_idx + 1, ['Criterion', 'Max Features', 'n_estimators']].to_dict()
    print(f"Best parameters for Random Forest Regressor: {best_param} with an accuracy of {max_acc}")
    return df, max_acc, min_acc, best_param

def fit(x,y):
    models = {
        ('Random Forest'            , RandomForestRegressor()),
        ('Linear Regression'        , LinearRegression()),
        ('Poisson Regression'       , PoissonRegressor()),
        ('Decision Tree'            , DecisionTreeRegressor()),
        ('Support Vector Machine'   , SVR()),
        ('KNN'                      , KNeighborsRegressor())
    }
    
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    
    model_accuracy_table = pd.DataFrame(index=[1,2,3,4,5], columns=['Metrics', 'Random Forest','Linear Regression', 'Poisson Regression', 'Decision Tree', 'Support Vector Machine', 'KNN'])
    
    Metrics = ['MSE', 'MAE', 'R2', 'RMSE', 'R2ADJ']
    
    model_accuracy_table['Metrics'] = Metrics
    
    for name, model in models: 
        model.fit(X_train,y_train.values.ravel()  )
        y_pred = model.predict(X_test)
        MSE =  mean_squared_error(y_test,y_pred)
        MAE = mean_absolute_error(y_test,y_pred)
        R2  =  r2_score(y_test,y_pred)
        RMSE = np.sqrt(MSE)
        R2ADJ = 1 - (1-R2) * (len(y_train)-1)/(len(y_train)-X_train.shape[1]-1)
        
        model_accuracy_table.loc[1, name]=MSE
        model_accuracy_table.loc[2, name]=RMSE
        model_accuracy_table.loc[3, name]=MAE
        model_accuracy_table.loc[4, name]=R2
        model_accuracy_table.loc[5, name]=R2ADJ
        
    acc_max = np.max(model_accuracy_table.iloc[3, 1:].values)
    best_model_name = model_accuracy_table.columns[model_accuracy_table.isin([acc_max]).any()].tolist()[0]
    
    print(f'As a result {best_model_name}, served as a best model with the R² value of {acc_max}')
        
    return model_accuracy_table


def fit_save(x,y):
    models = {
        ('Random Forest'            , RandomForestRegressor()),
        ('Linear Regression'        , LinearRegression()),
        ('Poisson Regression'       , PoissonRegressor()),
        ('Decision Tree'            , DecisionTreeRegressor()),
        ('Support Vector Machine'   , SVR()),
        ('KNN'                      , KNeighborsRegressor())
    }
    
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    
    model_accuracy_table = pd.DataFrame(index=[1,2,3,4,5], columns=['Metrics', 'Random Forest','Linear Regression', 'Poisson Regression', 'Decision Tree', 'Support Vector Machine', 'KNN'])
    
    Metrics = ['MSE', 'MAE', 'R2', 'RMSE', 'R2ADJ']
    
    model_accuracy_table['Metrics'] = Metrics
    
    for name, model in models: 
        model.fit(X_train,y_train.values.ravel()  )
        y_pred = model.predict(X_test)
        MSE =  mean_squared_error(y_test,y_pred)
        MAE = mean_absolute_error(y_test,y_pred)
        R2  =  r2_score(y_test,y_pred)
        RMSE = np.sqrt(MSE)
        R2ADJ = 1 - (1-R2) * (len(y_train)-1)/(len(y_train)-X_train.shape[1]-1)
        
        model_accuracy_table.loc[1, name]=MSE
        model_accuracy_table.loc[2, name]=RMSE
        model_accuracy_table.loc[3, name]=MAE
        model_accuracy_table.loc[4, name]=R2
        model_accuracy_table.loc[5, name]=R2ADJ
        
    acc_max = np.max(model_accuracy_table.iloc[3, 1:].values)
    best_model_name = model_accuracy_table.columns[model_accuracy_table.isin([acc_max]).any()].tolist()[0]
    
    print(f'As a result {best_model_name}, served as a best model with the R² value of {acc_max}')            
        
    print('')
    
    print('Saving the best model ...........')
    
    print('')
            
    best_model = [model for name, model in models if name == best_model_name][0]
    
    fileName = f"Finalized_model_{best_model_name}_Reg.sav"
    
    pk.dump(best_model, open(fileName, 'wb'))
    
    print('Model Saved succesfully') 
    
    print('')
            
    print(f"{fileName} is ready for deployment") 
        
    return model_accuracy_table
    