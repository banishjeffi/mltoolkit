from setuptools import setup

with open("README.md", "r", encoding="utf8") as fh:
    long_description = fh.read()

setup(
    name="mltoolkit",
    version="1.0.0",
    author="Banish J",
    author_email = "mail@banish.in",
    description="This Python package is made on behalf of making the AI and ML Tasks simple and productive to have a faster deployment of projects",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://pypi.org/project/mlstats',
    python_requires='>=3.11',
    install_requires=['numpy','pandas', 'matplotlib', 'scikit-learn', 'pickle4'],
    license='MIT',
    py_modules=['mltoolkit'],
    packages=['mltoolkit'],
    entry_points={
        'console_scripts': [
        'mlstats = mlstats.__main__:main'
        ]
    }
    )